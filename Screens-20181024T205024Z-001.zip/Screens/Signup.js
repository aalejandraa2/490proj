import  React from 'react';
import {StyleSheet, Text, View, Button} from 'react-native';


export default class Signup extends React.Component {
  static navigationOptions = {
    title: 'Signup Screen',
  };
  render() {
    return (
      <View style={styles.container}>
        <Text>This is the signup screen</Text>
        </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
