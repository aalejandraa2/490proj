/*
Main Page
*/
import  React from 'react';
import {StyleSheet, Text, View, Button} from 'react-native';


export default class Main extends React.Component {
  static navigationOptions = {
    title: 'Main Screen',
  };
  render() {
    return (
      <View style={styles.container}>
        <Text>REP</Text>
        <Text>Raspados | Elotes | Paletas</Text>
    
    
            <Button title = "Login"
                onPress ={ ()=> this.props.navigation.navigate('LoginScreen')}
                />
            <Button title = "Create an account"
                onPress ={ ()=> this.props.navigation.navigate('SignupScreen')}
                />
      </View>
    );
  }
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
